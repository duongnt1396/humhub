<?php

    return [
        'There is an update for the Weather module! ({version})' => 'There is an update for the Weather module! ({version})',
        'Receive Notifications new versions of the Weather module' => 'Receive Notifications new versions of the Weather module',
        'Weather Module Updates' => 'Weather Module Updates',

    ];
