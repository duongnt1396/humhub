<?php

    return [
        'There is an update for the Weather module! ({version})' => '',
        'Receive Notifications new versions of the Weather module' => '',
        'Weather Module Updates' => '',

    ];
