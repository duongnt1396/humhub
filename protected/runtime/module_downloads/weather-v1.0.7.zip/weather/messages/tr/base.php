<?php
return [
  '<strong>Weather</strong>' => '<strong>Weather</strong>',
  'Weather Settings' => 'Weather Ayarlar',
  'Weather URL:' => 'Weather URL:',
  '<strong>Weather</strong> module configuration' => '<strong>Weather</strong> modül yapılandırması',
  'Save' => 'Kaydet',
];
