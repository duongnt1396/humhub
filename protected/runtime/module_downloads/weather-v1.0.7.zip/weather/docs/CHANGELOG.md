# Changelogs
Date: *3/29/2020*
- Enh: Version Upgrade
- Enh: Updated Translations
- Enh: Changed Notification wording 

Date: *3/28/2020*
- Enh: Added archive.json & linked POEditor

Date: *3/26/2020*
- Fix: Refactoring 2

Date: *3/25/2020*
- Enh: Possible fix for broken link
- Enh: Create `notification.php`
- Fix: Translations broken
- Enh: Update HumHubAPI.php
- Enh: Delete `about.php`
- Enh: Minor clean up
- Enh: Update `notification.php`
- Enh: Version Update

Date: *3/24/2020*
- Internal dev release
- Enh: Optimizes images
- Enh: Fix broken URL field
- Enh: Initial commit
