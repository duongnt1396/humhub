[![Build Status](https://travis-ci.org/humhub/humhub-modules-polls.svg?branch=master)](https://travis-ci.org/humhub/humhub-modules-polls)

# Polls

Stop discussing, let the votes speak for themselves. Our Polls module allows you to resolve disputes quickly. Let the majority decide, or just get an opinion on your urgent questions. 

## Overviews

- Offer single or multiple choice
- Hide the results until the poll is closed
- Vote anonymously
- Discuss the results in the comments