<?php

return [
    'At least one answer is required' => '',
    'Allows to start polls.' => 'Atļauj uzsākt aptauju.',
    'Cancel' => 'Atcelt',
    'Polls' => 'Aptaujas',
    'Save' => 'Saglabāt',
];
