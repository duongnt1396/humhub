<?php
return array (
  'Answers' => 'Odpowiedzi',
  'Multiple answers per user' => 'Wielokrotne odpowiedzi na użytkownika',
  'Please specify at least {min} answers!' => 'Proszę określ przynajmniej {min} odpowiedzi! ',
  'Question' => 'Pytanie ',
);
