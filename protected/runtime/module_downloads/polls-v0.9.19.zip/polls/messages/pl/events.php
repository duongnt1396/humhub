<?php
return array (
  'Again? ;Weary;' => 'Znowu? ;Zmęczony;',
  'Club A Steakhouse' => 'Stek',
  'Pisillo Italian Panini' => 'Włoskie Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Planujemy właśnie etapy naszego kolejnego spotkania, chcemy się dowiedzieć gdzie chcesz się spotkać?',
  'To Daniel' => 'Do Daniela',
  'Why don\'t we go to Bemelmans Bar?' => 'Dlaczego nie skoczymy do Baru Mlecznego?',
);
