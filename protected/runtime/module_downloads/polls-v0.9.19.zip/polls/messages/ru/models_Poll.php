<?php
return array (
  'Answers' => 'Ответы',
  'Multiple answers per user' => 'Пользователь может выбирать несколько вариантов ответов',
  'Please specify at least {min} answers!' => 'Пожалуйста выберите хотя бы {min} ответ(ов)! ',
  'Question' => 'Опрос',
);
