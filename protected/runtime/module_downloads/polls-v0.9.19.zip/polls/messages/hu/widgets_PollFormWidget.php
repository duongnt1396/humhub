<?php
return array (
  'Ask' => 'Megkérdez',
);
