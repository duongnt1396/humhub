<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} létrehozott egy új szavazást és kijelölt téged.',
);
