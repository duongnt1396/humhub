<?php
return array (
  'User who vote this' => 'Felhasználók, akik szavaztak',
);
