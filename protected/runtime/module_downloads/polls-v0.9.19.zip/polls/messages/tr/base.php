<?php
return array (
  'Allows to start polls.' => 'Anket başlatmaya izin verir.',
  'At least one answer is required' => 'En az bir cevap gerekli',
  'Cancel' => 'İptal',
  'Polls' => 'Anketler',
  'Save' => 'Kaydet',
);
