<?php
return array (
  'Allows to start polls.' => 'Dopusti pokretanje ankete',
  'At least one answer is required' => 'Potreban je barem jedan odgovor',
  'Cancel' => 'Poništi',
  'Polls' => 'Ankete',
  'Save' => 'Spremi',
);
