<?php
return array (
  'Again? ;Weary;' => 'Ponovno? ;Weary;',
  'Club A Steakhouse' => 'Club A Steakhouse',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Trenutačno, planiramo naše sljedeće druženje i željeli bi znati gdje bi vi htjeli ići?',
  'To Daniel' => 'Za Daniela',
  'Why don\'t we go to Bemelmans Bar?' => 'Zašto ne idemo u Bemelmas Bar?',
);
