<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} kreirao je novu anketu i dodijelio je vas.',
);
