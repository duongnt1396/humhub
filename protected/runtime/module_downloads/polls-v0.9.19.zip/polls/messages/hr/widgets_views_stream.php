<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Još nema anketa!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Joše nema anketa!</b><br>Budite prvi i kreirajte jednu...',
  'Asked by me' => 'Pitan od mene',
  'No answered yet' => 'Još nema odgovora',
  'Only private polls' => 'Samo privatne ankete',
  'Only public polls' => 'Samo javne ankete',
);
