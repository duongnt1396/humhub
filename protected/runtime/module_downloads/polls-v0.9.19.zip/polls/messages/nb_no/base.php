<?php
return array (
  'Allows to start polls.' => 'Tillater å starte en meningsmåling.',
  'At least one answer is required' => 'Minst et svar er påkrevd',
  'Cancel' => 'Avbryt',
  'Polls' => 'Meningsmålinger',
  'Save' => 'Lagre',
);
