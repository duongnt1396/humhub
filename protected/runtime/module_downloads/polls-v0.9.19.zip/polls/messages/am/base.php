<?php
return array (
  'Allows to start polls.' => '',
  'At least one answer is required' => '',
  'Cancel' => 'ይቅር',
  'Polls' => '',
  'Save' => 'አስቀምጥ',
);
