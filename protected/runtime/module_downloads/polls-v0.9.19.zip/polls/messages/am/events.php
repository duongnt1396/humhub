<?php

return [
    'Again? ;Weary;' => '',
    'Club A Steakhouse' => '',
    'Pisillo Italian Panini' => '',
    'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => '',
    'To Daniel' => '',
    'Why don\'t we go to Bemelmans Bar?' => '',
];
