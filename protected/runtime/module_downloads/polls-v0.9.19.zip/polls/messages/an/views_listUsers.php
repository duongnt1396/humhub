<?php
return array (
  'User who vote this' => 'Usuarios que han votau isto',
);
