<?php

return [
    'At least one answer is required' => '',
    'Allows to start polls.' => 'Permitir iniciar enqüestas.',
    'Cancel' => 'Cancelar',
    'Polls' => 'Enqüestas',
    'Save' => 'Alzar',
];
