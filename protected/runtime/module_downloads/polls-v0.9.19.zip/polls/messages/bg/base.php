<?php

return [
    'Allows to start polls.' => '',
    'At least one answer is required' => '',
    'Cancel' => 'Отказ',
    'Polls' => 'Анкети',
    'Save' => 'Запази',
];
