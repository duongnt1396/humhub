<?php
return array (
  'Access denied!' => 'Достъп отказан!',
  'Anonymous poll!' => '',
  'Could not load poll!' => '',
  'Invalid answer!' => '',
  'Users voted for: <strong>{answer}</strong>' => '',
  'Voting for multiple answers is disabled!' => '',
  'You have insufficient permissions to perform that operation!' => '',
);
