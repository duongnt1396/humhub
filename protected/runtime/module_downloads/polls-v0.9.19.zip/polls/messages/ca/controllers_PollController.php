<?php
return array (
  'Access denied!' => 'Accés denegat!',
  'Anonymous poll!' => '',
  'Could not load poll!' => 'No s\'ha pogut carregar l\'enquesta!',
  'Invalid answer!' => 'Resposta incorrecta!',
  'Users voted for: <strong>{answer}</strong>' => 'Membres que han votat: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'No es permeten múltiples respostes!',
  'You have insufficient permissions to perform that operation!' => 'No tens suficients privilegis per realitzar aquesta acció!',
);
