<?php

return [
    'At least one answer is required' => '',
    'Allows to start polls.' => 'Permite iniciar encuestas.',
    'Cancel' => 'Cancelar',
    'Polls' => 'Votaciones',
    'Save' => 'Guardar',
];
