<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} vytvořil(a) novou anketu a přiřadil(a) vám ji.',
);
