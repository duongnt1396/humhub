<?php
return array (
  'Access denied!' => 'Toegang geweigerd!',
  'Anonymous poll!' => 'Anonieme stemmen',
  'Could not load poll!' => 'Kon stembus niet laden!',
  'Invalid answer!' => 'Ongeldig antwoord!',
  'Users voted for: <strong>{answer}</strong>' => 'Gebruikers stemden voor: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Stemmen voor meerdere antwoorden is uitgeschakeld!',
  'You have insufficient permissions to perform that operation!' => 'U hebt niet de nodige rechten om deze actie uit te voeren!',
);
