<?php
return array (
  'Allows to start polls.' => 'Starten van stembussen toestaan.',
  'At least one answer is required' => 'Ten minste één antwoord is vereist',
  'Cancel' => 'Annuleer',
  'Polls' => 'Stembus',
  'Save' => 'Bewaar',
);
