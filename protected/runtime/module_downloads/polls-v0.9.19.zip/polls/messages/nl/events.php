<?php
return array (
  'Again? ;Weary;' => 'Opnieuw? ;Weary;',
  'Club A Steakhouse' => 'Club A Steakhouse',
  'Pisillo Italian Panini' => 'Pisillo Italian Panini',
  'Right now, we are in the planning stages for our next meetup and we would like to know from you, where you would like to go?' => 'Op dit moment zijn we een nieuwe meeting aan het plannen en we willen graag van u weten waar u heen zou willen gaan.',
  'To Daniel' => 'Aan Daan',
  'Why don\'t we go to Bemelmans Bar?' => 'Waarom gaan we niet naar de Bemelman Bar?',
);
