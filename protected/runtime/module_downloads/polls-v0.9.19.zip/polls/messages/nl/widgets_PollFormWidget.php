<?php
return array (
  'Ask' => 'Vragen',
);
