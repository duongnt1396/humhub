<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Opmerking:</ strong> het resultaat  blijft verborgen totdat een  moderator de stembus sluit.',
  'Anonymous' => 'Anoniem',
  'Closed' => 'Gesloten',
  'Complete Poll' => 'Rond het stemmen af.',
  'Reopen Poll' => 'Heropen de stembus',
  'Reset my vote' => 'Reset mijn antwoord',
  'Vote' => 'Stem',
  'and {count} more vote for this.' => 'en {count} anderen hebben voor dit gestemd.',
  'votes' => 'stemmen',
);
