<?php

return [
    'At least one answer is required' => '',
    'Allows to start polls.' => 'Consente di iniziare un sondaggio.',
    'Cancel' => 'Annulla',
    'Polls' => 'Sondaggi',
    'Save' => 'Salva',
];
