<?php
return array (
  'Allows to start polls.' => 'Ermöglicht Umfragen zu starten.',
  'At least one answer is required' => 'Mindestens eine Antwort erforderlich.',
  'Cancel' => 'Abbrechen',
  'Polls' => 'Umfragen',
  'Save' => 'Speichern',
);
