<?php
return array (
  '<b>There are no polls yet!</b>' => '<b>Es gibt noch keine Umfragen!</b>',
  '<b>There are no polls yet!</b><br>Be the first and create one...' => '<b>Es gibt noch keine Umfragen!</b><br>Erstelle die erste ...',
  'Asked by me' => 'Von mir erstellt',
  'No answered yet' => 'Bisher nicht beantwortet',
  'Only private polls' => 'Nur private Umfragen',
  'Only public polls' => 'Nur öffentliche Umfragen',
);
