<?php
return array (
  'Access denied!' => 'Tillträde nekas!',
  'Anonymous poll!' => 'Anonym enkät!',
  'Could not load poll!' => '',
  'Invalid answer!' => 'Felaktigt svar!',
  'Users voted for: <strong>{answer}</strong>' => '',
  'Voting for multiple answers is disabled!' => '',
  'You have insufficient permissions to perform that operation!' => '',
);
