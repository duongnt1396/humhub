<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '',
  'Anonymous' => 'Anonym',
  'Closed' => 'Stängd',
  'Complete Poll' => '',
  'Reopen Poll' => '',
  'Reset my vote' => '',
  'Vote' => '',
  'and {count} more vote for this.' => '',
  'votes' => 'röster',
);
