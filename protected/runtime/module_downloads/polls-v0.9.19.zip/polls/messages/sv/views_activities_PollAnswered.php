<?php
return array (
  '{userName} answered the {question}.' => '{userName} svarade på {question}.',
);
