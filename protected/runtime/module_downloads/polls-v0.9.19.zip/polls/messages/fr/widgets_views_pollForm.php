<?php
return array (
  'Add answer...' => 'Ajouter une réponse...',
  'Anonymous Votes?' => 'Votes anonymes ?',
  'Ask something...' => 'Poser une question...',
  'Display answers in random order?' => 'Afficher les réponses dans un ordre aléatoire ?',
  'Edit answer (empty answers will be removed)...' => 'Modifier la réponse (les réponses vides seront supprimées)',
  'Edit your poll question...' => 'Modifier la question de votre sondage...',
  'Hide results until poll is closed?' => 'Cacher les résultats jusqu\'à ce que le sondage soit fermé ?',
);
