<?php
return array (
  'Allows to start polls.' => 'Antaa luoda kyselyitä',
  'At least one answer is required' => 'Tarvitaan vähintään yksi vastaus',
  'Cancel' => 'Peruuta',
  'Polls' => 'Kyselyt',
  'Save' => 'Tallenna',
);
