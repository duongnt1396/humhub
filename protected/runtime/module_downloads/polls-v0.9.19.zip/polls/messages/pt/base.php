<?php

return [
    'Allows to start polls.' => '',
    'At least one answer is required' => '',
    'Cancel' => '',
    'Polls' => '',
    'Save' => 'Guardar',
];
