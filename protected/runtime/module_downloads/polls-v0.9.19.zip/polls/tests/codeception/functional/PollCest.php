<?php

namespace polls\functional;

use polls\FunctionalTester;
use Yii;
use humhub\modules\breakingnews\models\EditForm;

class PollsNewsCest
{

    
    public function testNewsActivation(FunctionalTester $I)
    {
    }

}
