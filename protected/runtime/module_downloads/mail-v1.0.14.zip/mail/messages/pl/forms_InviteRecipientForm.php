<?php
return array (
  'Recipient' => 'Odbiorca',
  'User {name} is already participating!' => 'Użytkownik {name} już uczestniczy!',
  'You are not allowed to send user {name} is already!' => 'Nie masz uprawnień aby wysyłać osobie {name} wiadomości!',
  'You cannot send a email to yourself!' => 'Nie możesz wysłać wiadomości do samego siebie!',
);
