<?php
return array (
  'New message' => 'Yeni mesaj',
  'Send message' => 'Mesaj gönder',
);
