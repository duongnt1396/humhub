<?php
return array (
  '<strong>New</strong> message' => '<strong>Yeni</strong> mesaj',
  'Reply now' => 'Cevapla',
  'sent you a new message:' => 'yeni bir mesaj gönder:',
);
