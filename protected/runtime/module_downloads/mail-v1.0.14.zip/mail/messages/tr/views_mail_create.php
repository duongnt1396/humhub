<?php

return [
    'Add recipients' => 'Alıcıları ekle',
    'New message' => 'Yeni mesaj',
    'Send' => 'Gönder',
];
