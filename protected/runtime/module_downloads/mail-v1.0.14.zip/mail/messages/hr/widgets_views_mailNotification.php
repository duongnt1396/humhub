<?php
return array (
  'Messages' => 'Poruke',
  'New message' => 'Nova poruka',
  'Show all messages' => 'Prikaži sve poruke',
);
