<?php
return array (
  'New message in discussion from %displayName%' => '%displayName%さんから新しいディスカッションメッセージ',
);
