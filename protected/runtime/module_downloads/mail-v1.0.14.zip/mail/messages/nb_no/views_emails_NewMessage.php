<?php
return array (
  '<strong>New</strong> message' => '<strong>Ny</strong> melding',
  'Reply now' => 'Svar nå',
  'sent you a new message:' => 'sendte deg en ny melding:',
);
