<?php

return [
    'Edit message entry' => 'Rediger melding',
];
