<?php

return [
    'Add recipients' => 'Добавить получателей',
    'New message' => 'Новое сообщение',
    'Send' => 'Отправить',
];
