<?php

return [
    'Add more participants to your conversation...' => 'Добавить участников в переписку...',
];
