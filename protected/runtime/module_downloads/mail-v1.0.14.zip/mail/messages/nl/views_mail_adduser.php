<?php

return [
    'Add more participants to your conversation...' => 'Voeg meer deelnemers toe aan je conversatie...',
];
