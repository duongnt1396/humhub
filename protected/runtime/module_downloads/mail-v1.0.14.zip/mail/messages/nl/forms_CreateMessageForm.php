<?php
return array (
  'Message' => 'Bericht',
  'Recipient' => 'Ontvanger',
  'Subject' => 'Onderwerp',
  'You cannot send a email to yourself!' => 'Je kunt jezelf geen mail sturen!',
);
