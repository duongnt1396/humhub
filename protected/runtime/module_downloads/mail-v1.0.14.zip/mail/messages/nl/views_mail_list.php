<?php
return array (
  'There are no messages yet.' => 'Er zijn nog geen berichten.',
);
