<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'گيرنده',
    'You cannot send a email to yourself!' => 'شما نمي توانيد به خودتان پيام بفرستيد',
];
