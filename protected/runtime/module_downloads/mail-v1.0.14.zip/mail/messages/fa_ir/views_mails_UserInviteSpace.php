<?php
return array (
  'Sign up now' => 'الان ثبت نام کنید',
);
