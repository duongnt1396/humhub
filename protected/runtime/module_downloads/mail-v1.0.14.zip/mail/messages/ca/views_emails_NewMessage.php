<?php
return array (
  '<strong>New</strong> message' => '<strong>Nou</strong> missatge',
  'Reply now' => 'Respon ara',
  'sent you a new message:' => 't\'ha enviat un nou missatge:',
);
