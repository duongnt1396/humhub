<?php
return array (
  'New message' => 'Nou missatge',
  'Send message' => '',
);
