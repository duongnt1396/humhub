<?php
return array (
  'Recipient' => 'Empfänger',
  'User {name} is already participating!' => 'Benutzer {name} ist bereits dabei!',
  'You are not allowed to send user {name} is already!' => 'You are not allowed to send user {name} is already!',
  'You cannot send a email to yourself!' => 'Du kannst dir selber keine Mail senden!',
);
