<?php
return array (
  'sent you a new message in' => 'hat dir eine neue Nachricht geschickt in',
);
