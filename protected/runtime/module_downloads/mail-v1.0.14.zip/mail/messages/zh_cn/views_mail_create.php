<?php

return [
    'Add recipients' => '增加收件人',
    'New message' => '新的消息',
    'Send' => '发送',
];
