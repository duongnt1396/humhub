<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => '收件人',
    'You cannot send a email to yourself!' => '你不能给自己发邮件！',
];
