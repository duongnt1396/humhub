<?php
return array (
  'New message in discussion from %displayName%' => '来自 %displayName% 的新讨论消息',
);
