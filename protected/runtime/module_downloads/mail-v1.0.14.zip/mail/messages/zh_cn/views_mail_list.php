<?php
return array (
  'There are no messages yet.' => '还没有消息.',
);
