<?php
return array (
  'Add recipients' => '',
  'New message' => '',
  'Send' => 'Στείλε',
);
