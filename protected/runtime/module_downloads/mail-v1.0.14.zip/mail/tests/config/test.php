<?php

return [
    'modules' => ['mail'],
    'fixtures' => [
        'default',
        'message' => 'tests\codeception\fixtures\MessageFixture'
    ]
];
