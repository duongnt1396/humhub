<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Új oldal</strong> létrehozása',
  '<strong>Edit</strong> page' => 'Oldal <strong>szerkesztése</strong>',
  'New page title' => 'Oldal új címe',
);
