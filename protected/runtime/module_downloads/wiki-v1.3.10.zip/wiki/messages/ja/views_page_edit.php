<?php

return [
    '<strong>Create</strong> new page' => '',
    'New page title' => '',
    '<strong>Edit</strong> page' => '<strong>編集</strong> ページ',
];
