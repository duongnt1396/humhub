<?php
return array (
  'Wiki page' => 'Trang Kiến thức',
);
