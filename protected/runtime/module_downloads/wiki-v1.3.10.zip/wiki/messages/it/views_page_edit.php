<?php

return [
    '<strong>Create</strong> new page' => '<strong>Crea</strong> una nuova pagina',
    '<strong>Edit</strong> page' => '<strong>Modifica</strong> pagina',
    'New page title' => 'Titolo nuova pagina',
];
