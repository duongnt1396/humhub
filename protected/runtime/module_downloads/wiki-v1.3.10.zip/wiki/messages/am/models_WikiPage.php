<?php

return [
    'Wiki page' => '',
];
