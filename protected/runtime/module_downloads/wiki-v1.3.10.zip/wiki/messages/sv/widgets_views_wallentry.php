<?php
return array (
  'Open wiki page...' => 'Öppna wikisida',
);
