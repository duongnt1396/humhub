<?php

return [
    '<strong>Create</strong> new page' => '<strong>Utwórz</strong> nową stronę',
    '<strong>Edit</strong> page' => '<strong>Edytuj</strong> stronę',
    'New page title' => 'Nowy tytuł strony',
];
