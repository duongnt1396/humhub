<?php
return array (
  'Wiki page' => 'Blogi',
);
