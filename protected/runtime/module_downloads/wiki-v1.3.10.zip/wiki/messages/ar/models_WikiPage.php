<?php
return array (
  'Wiki page' => 'صفحة ويكي',
);
