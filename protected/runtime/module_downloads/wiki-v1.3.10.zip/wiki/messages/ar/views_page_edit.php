<?php

return [
    '<strong>Create</strong> new page' => '<strong>بدء</strong> صفحة جديدة',
    '<strong>Edit</strong> page' => '<strong>تعديل</strong> صفحة',
    'New page title' => 'عنوان صفحة جديد',
];
