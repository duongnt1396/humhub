Changelog
=========

0.2.6 - June 17, 2019
-----------------------
- Enh: Updated translations
- Enh: Improved docs
