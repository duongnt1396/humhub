# Most Active Users

Create engagement by showing your users who is really actively involved. Integrate the ranking of the most active users in your dashboard and let the race for the top begin.

## Overview

- Add rankings as a widget to the dashboard
- Set the number of users shown
- Expand the list to get more details