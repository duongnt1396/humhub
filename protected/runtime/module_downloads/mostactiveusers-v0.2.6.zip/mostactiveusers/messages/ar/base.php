<?php
return array (
  '<strong>Most</strong> active people' => '',
  'Back to modules' => 'العودة للموديولات',
  'Get a list' => '',
  'Most Active Users Module Configuration' => '',
  'Save' => 'حفظ',
  'The number of most active users that will be shown.' => '',
  'You may configure the number users to be shown.' => '',
);
