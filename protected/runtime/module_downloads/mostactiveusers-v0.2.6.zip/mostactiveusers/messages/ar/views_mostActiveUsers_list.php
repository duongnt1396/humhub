<?php
return array (
  '<strong>Most</strong> active people' => '',
  'Comments created' => '',
  'Likes given' => '',
  'Posts created' => '',
);
