<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Legaktivabb</strong> emberek',
  'Comments created' => 'Hozzászólások',
  'Likes given' => 'Kedvelések',
  'Posts created' => 'Létrehozott bejegyzések',
);
