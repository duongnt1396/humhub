<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Legaktivabb</strong> emberek',
  'Back to modules' => 'Vissza a modulokhoz',
  'Get a list' => 'Lista mutatása',
  'Most Active Users Module Configuration' => 'Legaktívabb felhasználók modul beállítása',
  'Save' => 'Mentés',
  'The number of most active users that will be shown.' => 'A megjelenítendő legaktívabb felhasználók száma.',
  'You may configure the number users to be shown.' => 'Beállíthatod a megjelenítendő felhasználók számát.',
);
