<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Aktif</strong> kişiler',
  'Comments created' => 'Yorumlar',
  'Likes given' => 'Beğeniler',
  'Posts created' => 'Mesajlar',
);
