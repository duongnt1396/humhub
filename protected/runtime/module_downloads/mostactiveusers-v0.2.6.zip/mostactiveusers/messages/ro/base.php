<?php
return array (
  '<strong>Most</strong> active people' => '',
  'Back to modules' => 'Înapoi la module',
  'Get a list' => '',
  'Most Active Users Module Configuration' => '',
  'Save' => 'Salvează',
  'The number of most active users that will be shown.' => '',
  'You may configure the number users to be shown.' => '',
);
