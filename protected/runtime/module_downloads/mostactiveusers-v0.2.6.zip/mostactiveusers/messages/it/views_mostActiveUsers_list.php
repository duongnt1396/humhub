<?php
return array (
  '<strong>Most</strong> active people' => 'Le persone <strong>più</strong> attive',
  'Comments created' => 'Commenti creati',
  'Likes given' => 'Mi piace assegnati',
  'Posts created' => 'Post creati',
);
