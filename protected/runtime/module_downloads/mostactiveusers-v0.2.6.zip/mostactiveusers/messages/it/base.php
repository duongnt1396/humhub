<?php
return array (
  '<strong>Most</strong> active people' => 'Le persone <strong>più</strong> attive',
  'Back to modules' => 'Indietro ai moduli',
  'Get a list' => 'Ottieni elenco',
  'Most Active Users Module Configuration' => 'Configurazione modulo Most Active Users',
  'Save' => 'Salva',
  'The number of most active users that will be shown.' => 'Il numero di utenti più attive che verrà mostrato',
  'You may configure the number users to be shown.' => 'Puoi configurare il numero di utenti da mostrare.',
);
