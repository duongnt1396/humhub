<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Flest</strong> aktive brukere',
  'Back to modules' => 'Tilbake til moduler',
  'Get a list' => 'Se listen',
  'Most Active Users Module Configuration' => 'Flest aktive brukere modul konfigurasjon',
  'Save' => 'Lagre',
  'The number of most active users that will be shown.' => 'Det høyeste nummer av aktive brukere som vil vises',
  'You may configure the number users to be shown.' => 'Du kan konfigurere antall brukere som vises',
);
