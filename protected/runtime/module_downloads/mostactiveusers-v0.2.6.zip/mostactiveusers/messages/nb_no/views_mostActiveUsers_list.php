<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Flest</strong> aktive brukere',
  'Comments created' => 'Kommentarer laget',
  'Likes given' => 'Likes gitt',
  'Posts created' => 'Poster laget',
);
