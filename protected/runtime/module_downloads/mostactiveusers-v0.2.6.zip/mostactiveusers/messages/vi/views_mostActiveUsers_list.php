<?php
return array (
  '<strong>Most</strong> active people' => 'Thành viên năng động <strong>nhất</strong>',
  'Comments created' => 'Comment đã được tạo',
  'Likes given' => 'Likes được tặng',
  'Posts created' => 'Posts đã tạo',
);
