<?php
return array (
  '<strong>Most</strong> active people' => 'Thành viên năng động <strong>nhất</strong>',
  'Back to modules' => 'Trở lại Modules',
  'Get a list' => 'Chọn một danh sách',
  'Most Active Users Module Configuration' => 'Cấu hình module thành viên năng động nhất',
  'Save' => 'Lưu',
  'The number of most active users that will be shown.' => 'Số user năng động nhất sẽ được hiển thị',
  'You may configure the number users to be shown.' => 'Bạn có thể cấu hình số user được hiển thị',
);
