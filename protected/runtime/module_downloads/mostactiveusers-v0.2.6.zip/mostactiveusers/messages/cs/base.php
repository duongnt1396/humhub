<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Nejvíce </strong> aktivní uživatelé',
  'Back to modules' => 'Zpět na přehled modulů',
  'Get a list' => 'Získat seznam',
  'Most Active Users Module Configuration' => 'Konfigurace modulu nejaktivnějších uživatelů',
  'Save' => 'Uložit',
  'The number of most active users that will be shown.' => 'Počet nejaktivnějších uživatelů, kteří se zobrazí.',
  'You may configure the number users to be shown.' => 'Můžete konfigurovat počet uživatelů, kteří mají být zobrazeni.',
);
