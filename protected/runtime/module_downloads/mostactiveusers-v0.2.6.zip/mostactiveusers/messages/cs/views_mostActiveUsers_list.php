<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Nejvíce</strong> aktivní lidé',
  'Comments created' => 'Vytvořeny komentáře',
  'Likes given' => 'To se mi líbí',
  'Posts created' => 'Vytvořeny příspěvky',
);
