<?php
return array (
  '<strong>Most</strong> active people' => 'کاربران با  <strong>بیشترین فعالیت</strong>',
  'Comments created' => 'نظرهای ایجادشده',
  'Likes given' => 'لایک‌های داده‌شده',
  'Posts created' => 'پست‌های ایجادشده',
);
