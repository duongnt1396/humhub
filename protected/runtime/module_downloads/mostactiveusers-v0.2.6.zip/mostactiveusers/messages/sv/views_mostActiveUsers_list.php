<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Mest</strong> aktiva personer',
  'Comments created' => 'Kommentar skapad',
  'Likes given' => 'Gillas',
  'Posts created' => 'Post skapad',
);
