<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Mest</strong> aktiva personer',
  'Back to modules' => 'Tillbaka till moduler',
  'Get a list' => 'Hämta lista',
  'Most Active Users Module Configuration' => 'Mest aktiva personer - inställningar',
  'Save' => 'Spara',
  'The number of most active users that will be shown.' => 'Antalet aktiva användare som ska visas',
  'You may configure the number users to be shown.' => '',
);
