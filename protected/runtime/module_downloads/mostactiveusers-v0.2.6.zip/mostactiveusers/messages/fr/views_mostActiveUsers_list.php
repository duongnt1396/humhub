<?php
return array (
  '<strong>Most</strong> active people' => 'Les membres <strong>les plus actifs</strong>',
  'Comments created' => 'Commentaire(s)',
  'Likes given' => 'Mention(s) "J\'aime"',
  'Posts created' => 'Publication(s)',
);
