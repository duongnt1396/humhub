<?php
return array (
  '<strong>Most</strong> active people' => 'Les membres <strong>les plus actifs</strong>',
  'Back to modules' => 'Retour aux modules',
  'Get a list' => 'Liste',
  'Most Active Users Module Configuration' => 'Configuration du module "Most Active Users"',
  'Save' => 'Enregistrer',
  'The number of most active users that will be shown.' => 'Le nombre de membres devant être affiché.',
  'You may configure the number users to be shown.' => 'Vous devez spécifier le nombre de membres qui doivent être affichés.',
);
