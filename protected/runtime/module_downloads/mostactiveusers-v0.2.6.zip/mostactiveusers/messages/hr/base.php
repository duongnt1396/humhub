<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Najaktivniji</strong> ljudi',
  'Back to modules' => 'Povratak na module',
  'Get a list' => 'Dobiti popis',
  'Most Active Users Module Configuration' => 'Konfiguracija modula najaktivnijih korisnika',
  'Save' => 'Spremi',
  'The number of most active users that will be shown.' => 'Broj najaktivnijih korisnika koji će biti prikazani.',
  'You may configure the number users to be shown.' => 'Možete konfigurirati broj korisnika koji će biti prikazani.',
);
