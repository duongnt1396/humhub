<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Najaktivniji</strong> ljudi',
  'Comments created' => 'Kreirano komentara',
  'Likes given' => 'Sviđa mi se',
  'Posts created' => 'Objava kreirano',
);
