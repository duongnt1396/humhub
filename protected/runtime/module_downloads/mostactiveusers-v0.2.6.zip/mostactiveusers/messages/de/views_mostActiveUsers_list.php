<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Aktivste</strong> Benutzer',
  'Comments created' => 'Erstellte Kommentare',
  'Likes given' => 'Abgegebene "Gefällt mir"',
  'Posts created' => 'Erstellte Posts',
);
