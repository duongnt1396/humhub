<?php
return array (
  '<strong>Most</strong> active people' => '<strong>Aktivste</strong> Benutzer',
  'Back to modules' => 'Zurück zu den Modulen',
  'Get a list' => 'Liste ansehen',
  'Most Active Users Module Configuration' => 'Aktivste-Benutzer-Modul Einstellungen ',
  'Save' => 'Speichern',
  'The number of most active users that will be shown.' => 'Die Anzahl der aktivsten Benutzer, die angezeigt werden.',
  'You may configure the number users to be shown.' => 'Du kannst die Anzahl der anzuzeigenden Benutzer konfigurieren.',
);
